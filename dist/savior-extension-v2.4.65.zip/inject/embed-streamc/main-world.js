document.querySelector("video").setAttribute("savior-video-detail", window.videoHash);
