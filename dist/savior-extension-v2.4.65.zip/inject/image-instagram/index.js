var a;
a = location.href;
chrome.runtime.sendMessage(null, {
  type: "script_executed",
  data: {
    data: {
      origin: "instagram.com",
      url: a
    }
  }
}).catch(() => {});
